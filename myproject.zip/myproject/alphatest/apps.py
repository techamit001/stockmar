from django.apps import AppConfig


class AlphatestConfig(AppConfig):
    name = 'alphatest'
