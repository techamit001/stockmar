var unique_data = data;
document.getElementById("a").innerHTML = unique_data;


	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="{% static 'js/graph.js' %}"></script>